package input;

import java.util.ArrayList;

import javax.swing.JTextArea;

public interface DocumentReader {
	public void read(String FormatedFilePath,JTextArea userData);
}
